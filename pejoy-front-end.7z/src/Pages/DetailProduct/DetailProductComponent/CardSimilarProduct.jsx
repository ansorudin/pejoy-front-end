import React from 'react'

const CardSimilarProduct = () => {
    return (
        <div style={{paddingTop : 120}}>
            <div>
                
            </div>
            
        </div>
    )
}

export default CardSimilarProduct
