import React from 'react'

const ProductDescription = () => {
    return (
        <div style={{height : 500}}>
            ini description
        </div>
    )
}

export default ProductDescription