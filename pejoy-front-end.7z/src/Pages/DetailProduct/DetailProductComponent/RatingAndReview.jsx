import React from 'react'

const RatingAndReview = () => {
    return (
        <div>
            ini rating
        </div>
    )
}

export default RatingAndReview
