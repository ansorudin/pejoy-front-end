export const cardData=[{
    title:'Verifikasi no hape mu',
    image:'https://www.static-src.com/frontend/member/static/img/increase-your-account-security.e6caa76.png',
    title_2:'Tingkatkan akun keamananmu',
    desc:'Perlindungan tambahan untuk akunmu biar tidak kecolongan.',
    left:'nanti saja',
    right:'lanjut'
    },
    {
        title:'Verifikasi no hape mu',
        image:'https://www.static-src.com/frontend/member/static/img/get-order-notification-by-sms.b2af3a6.png',
        title_2:'Notifikasi pesanan lewat SMS',
        desc:'Selalu tahu status terbaru pesanan kamu lewat SMS.',
        left:'kembali',
        right:'lanjut'
    },
    {
        title:'Verifikasi no hape mu',
        image:'https://www.static-src.com/frontend/member/static/img/get-promo.11cf5d0.png',
        title_2:'Dapat promo spesial',
        desc:'Banyak promo spesial hanya untukmu yang sudah verifikasi.',
        left:'kembali',
        right:'lanjut'
    },
    {
        title:'Verifikasi no hape mu',
        image:'https://www.static-src.com/frontend/member/static/img/get-point-when-shopping.9406f6b.png',
        title_2:'Dapat poin tiap transaksi',
        desc:'Bisa tukar poinnya jadi voucher, juga bisa meningkatkan level membership kamu.',
        left:'kembali',
        right:'lanjut'
    },
    {
        title:'Verifikasi no hape mu',
        image:'https://www.static-src.com/frontend/member/static/img/active-blipay-payment-method.51f7dc1.png',
        title_2:'Bisa aktifkan Blipay',
        desc:'Bayar ini-itu lebih praktis dengan metode pembayaran Blipay.',
        left:'nanti saja',
        right:'verifikasi sekarang'
    },


]