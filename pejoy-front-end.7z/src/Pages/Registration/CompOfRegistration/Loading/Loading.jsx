import React from 'react'
import './loading.css'

const FhLoading = ()=>{
    return  <div class="reg-ring-1"></div>
     

}


export default FhLoading