import Socket from 'socket.io-client';


export const io = Socket('http://localhost:4000');